#!/bin/bash
/usr/local/Gentouch_S/GT_service stop
cat /usr/local/Gentouch_S/GentouchS.conf | grep -v Max | grep -v Min | grep -v SwapXY > /usr/local/Gentouch_S/GentouchS.conf.bak
/usr/local/Gentouch_S/GTscal $1
sleep 1
cat /usr/local/Gentouch_S/GentouchS.conf >>/usr/local/Gentouch_S/GentouchS.conf.bak
cp -fr /usr/local/Gentouch_S/GentouchS.conf.bak /usr/local/Gentouch_S/GentouchS.conf
/usr/local/Gentouch_S/GT_service stop
sleep 1
/usr/local/Gentouch_S/GT_service start

